import React from 'react'

const Discover = () => {
  return (
    <div>
        Discover
    </div>
  )
}

export default Discover

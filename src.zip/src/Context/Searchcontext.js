import { createContext } from "react";

export const Searchcontext = createContext({
  labelval: "",
  sendLabelVal: () => {},
});

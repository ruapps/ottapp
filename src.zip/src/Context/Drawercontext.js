import { createContext } from "react";

export const Drawercontext = createContext({
  Categories: {},
  sendCategories: () => {},
});
